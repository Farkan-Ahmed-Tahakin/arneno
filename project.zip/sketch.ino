// LED pins
const int GREEN  = 13;
const int YELLOW = 12;
const int RED    = 8;
const int BLUE   = 7;

void setup() {
  pinMode(GREEN, OUTPUT);
  pinMode(YELLOW, OUTPUT);
  pinMode(RED, OUTPUT);
  pinMode(BLUE, OUTPUT);
}

void loop() {

  // Green LED
  digitalWrite(GREEN, HIGH);
  delay(1000);
  digitalWrite(GREEN, LOW);

  // Yellow LED
  digitalWrite(YELLOW, HIGH);
  delay(1000);
  digitalWrite(YELLOW, LOW);

  // Red LED
  digitalWrite(RED, HIGH);
  delay(1000);
  digitalWrite(RED, LOW);

  // Blue LED
  digitalWrite(BLUE, HIGH);
  delay(1000);
  digitalWrite(BLUE, LOW);

}
